ANNOUNCEMENT_TITLE_DESCRIPTION = """
This is the title of the announcement.
"""

ANNOUNCEMENT_BODY_DESCRIPTION = """
This is the message of the announcement.
"""

ANNOUNCEMENT_DATE_DESCRIPTION = """
This places a date on your announcement.
"""

ANNOUNCEMENT_STATUS_DESCRIPTION = """
Your students will not see this announcement until you select "Public".
"""
